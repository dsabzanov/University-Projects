<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Add Restaurant Hours</div>

                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="addhours">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <input id="id" type="hidden" class="form-control" name="id" value="<?php echo e($id); ?>" required>
                        </div>
                        
                        
                        <div class="form-group">
                            <label for="day" class="col-md-4 control-label">Day</label>
                            <div class="col-md-6">
                                <select class="form-control" id="day" name="day" required>
                                    <option>Sunday</option>
                                    <option>Monday</option>
                                    <option>Tuesday</option>
                                    <option>Wednesday</option>
                                    <option>Thursday</option>
                                    <option>Friday</option>
                                    <option>Saturday</option>
                                </select>
                            </div>
                        </div>
                        
                        

                        <div class="form-group<?php echo e($errors->has('starttime') ? ' has-error' : ''); ?>">
                            <label for="starttime" class="col-md-4 control-label">Start Time</label>

                            <div class="col-md-6">
                                <input id="starttime" type="text" class="form-control" placeholder="14:00:00" name="starttime" value="<?php echo e(old('starttime')); ?>" required>

                                <?php if($errors->has('starttime')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('starttime')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('endtime') ? ' has-error' : ''); ?>">
                            <label for="endtime" class="col-md-4 control-label">End Time</label>

                            <div class="col-md-6">
                                <input id="endtime" type="text" class="form-control" placeholder="20:00:00" name="endtime" value="<?php echo e(old('endtime')); ?>" required>

                                <?php if($errors->has('endtime')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('endtime')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        


                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Add Restaurant Hours
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>