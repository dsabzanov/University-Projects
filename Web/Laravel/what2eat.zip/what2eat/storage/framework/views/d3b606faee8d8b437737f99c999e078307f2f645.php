<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Restaurant Details</div>

                <div class="panel-body">
                    <h3><?php echo e($restaurantdetails->name); ?></h3> 
                    <?php if(Auth::check()): ?>
                        <?php if(Auth::user()->admin == 1): ?>
                            <a href="editrestaurant?id=<?php echo e($restaurantdetails->id); ?>">Edit Restaurant</a>
                            <a href="addhours?id=<?php echo e($restaurantdetails->id); ?>">Add Operating Hours</a>
                            <a href="addmenu?id=<?php echo e($restaurantdetails->id); ?>">Add Menu Item</a>
                        <?php elseif(Auth::user()->admin == 0): ?>
                            <a href="addreview?id=<?php echo e($restaurantdetails->id); ?>">Add Review</a>
                        <?php endif; ?>
                    <?php endif; ?>
                    <h4>Average Rating: </h4><?php echo e($average); ?>

                    <h4>Restaurant Info: </h4>
                    <p><?php echo e($restaurantdetails->streetaddress); ?></p>
                    <p><?php echo e($restaurantdetails->city); ?>, <?php echo e($restaurantdetails->state); ?></p>
                    <p><a href="<?php echo e($restaurantdetails->website); ?>"><?php echo e($restaurantdetails->website); ?></a></p>
                    
                    <h4>Hours: </h4>
                    <?php $__currentLoopData = $hours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($hour->day); ?>: <?php echo e($hour->starttime); ?> to <?php echo e($hour->endtime); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <h4>Menu: </h4>
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($menu->name); ?></p>
                        <p>Price: $<?php echo e($menu->price); ?></p>
                        <p>Description: <?php echo e($menu->description); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <h4>Reviews: </h4>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>